#include "imageinfo.h"
#include <QDir>
#include <QImage>
#include <QFileInfo>
#include <QString>

ImageInfo getImageInfo(const QString& filePath) {
    QImage image(filePath);
    ImageInfo info;
    info.fileName = QFileInfo(filePath).fileName();
    if (!image.isNull()) {
        info.size = image.size();
        // Separate horizontal and vertical DPI calculations
        info.horizontalDPI = image.dotsPerMeterX() / 39.3701;
        info.verticalDPI = image.dotsPerMeterY() / 39.3701;
        info.colorDepth = image.depth();

        // Calculate uncompressed size (assuming BMP format)
        int uncompressedSize = image.width() * image.height() * (image.depth() / 8);

        // Calculate compressed size
        QFileInfo fileInfo(filePath);
        int compressedSize = fileInfo.size();

        // Calculate compression ratio
        info.compressionRatio = 100.0 * (uncompressedSize - compressedSize) / uncompressedSize;

        // Detect compression
        if (filePath.endsWith(".jpg") || filePath.endsWith(".jpeg")) {
            info.compression = "JPEG Compression";
        } else if (filePath.endsWith(".png")) {
            info.compression = "PNG Compression";
        } else if (filePath.endsWith(".gif")) {
            info.compression = "GIF Compression";
        } else if (filePath.endsWith(".tif") || filePath.endsWith(".tiff")) {
            info.compression = "TIFF Compression";
        } else if (filePath.endsWith(".bmp")) {
            info.compression = "BMP Compression (none)";
        } else if (filePath.endsWith(".pcx")) {
            info.compression = "PCX Compression";
        } else {
            info.compression = "Unknown";
        }
    }
    return info;
}

QVector<ImageInfo> processImageDirectory(const QString& directoryPath) {
    QVector<ImageInfo> imageInfoList;
    QDir dir(directoryPath);
    QStringList filters;
    filters << "*.jpg" << "*.jpeg" << "*.gif" << "*.tif" << "*.bmp" << "*.png" << "*.pcx";
    QFileInfoList fileList = dir.entryInfoList(filters, QDir::Files);

    foreach (const QFileInfo& fileInfo, fileList) {
        ImageInfo info = getImageInfo(fileInfo.absoluteFilePath());
        imageInfoList.append(info);
    }
    return imageInfoList;
}
