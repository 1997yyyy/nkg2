#ifndef IMAGEINFO_H
#define IMAGEINFO_H

#include <QString>
#include <QSize>
#include <QVector>

struct ImageInfo {
    QString fileName;
    QSize size;
    double horizontalDPI;
    double verticalDPI;
    int colorDepth;
    QString compression;
    double compressionRatio;  // Add compression ratio
};

ImageInfo getImageInfo(const QString& filePath);
QVector<ImageInfo> processImageDirectory(const QString& directoryPath);

#endif // IMAGEINFO_H
