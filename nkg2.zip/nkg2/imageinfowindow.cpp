#include "imageinfowindow.h"
#include <QVBoxLayout>
#include <QDir>
#include <QFileDialog>
#include <QHeaderView>
#include <QHBoxLayout>

ImageInfoWindow::ImageInfoWindow(QWidget *parent) : QMainWindow(parent) {
    tableWidget = new QTableWidget(this);
    tableWidget->setColumnCount(7); // Update to 7 columns
    tableWidget->setHorizontalHeaderLabels({"File Name", "Image Size", "Horizontal DPI", "Vertical DPI", "Color Depth", "Compression", "Compression Ratio (%)"});
    tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    uploadButton = new QPushButton("Upload Files", this);
    connect(uploadButton, &QPushButton::clicked, this, &ImageInfoWindow::uploadFiles);

    downloadDirButton = new QPushButton("Select Download Directory", this);
    connect(downloadDirButton, &QPushButton::clicked, this, &ImageInfoWindow::selectDownloadDirectory);

    downloadDirLineEdit = new QLineEdit(this);
    downloadDirLineEdit->setPlaceholderText("Selected Directory...");

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(tableWidget);

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addWidget(uploadButton);
    buttonLayout->addWidget(downloadDirButton);
    buttonLayout->addWidget(downloadDirLineEdit);

    layout->addLayout(buttonLayout);

    QWidget *container = new QWidget;
    container->setLayout(layout);
    setCentralWidget(container);
}

void ImageInfoWindow::uploadFiles() {
    QStringList fileNames = QFileDialog::getOpenFileNames(this, "Select Image Files", "", "Images (*.jpg *.jpeg *.gif *.tif *.bmp *.png *.pcx)");
    if (!fileNames.isEmpty()) {
        QVector<ImageInfo> imageInfoList;
        for (const QString &filePath : fileNames) {
            ImageInfo info = getImageInfo(filePath);
            imageInfoList.append(info);
        }
        displayImageInfo(imageInfoList);
    }
}

void ImageInfoWindow::selectDownloadDirectory() {
    QString dir = QFileDialog::getExistingDirectory(this, "Select Download Directory");
    if (!dir.isEmpty()) {
        downloadDirLineEdit->setText(dir);
    }
}

void ImageInfoWindow::displayImageInfo(const QVector<ImageInfo>& imageInfoList) {
    tableWidget->setRowCount(imageInfoList.size());
    for (int i = 0; i < imageInfoList.size(); ++i) {
        tableWidget->setItem(i, 0, new QTableWidgetItem(imageInfoList[i].fileName));
        tableWidget->setItem(i, 1, new QTableWidgetItem(QString::number(imageInfoList[i].size.width()) + " x " + QString::number(imageInfoList[i].size.height())));
        tableWidget->setItem(i, 2, new QTableWidgetItem(QString::number(imageInfoList[i].horizontalDPI)));
        tableWidget->setItem(i, 3, new QTableWidgetItem(QString::number(imageInfoList[i].verticalDPI)));
        tableWidget->setItem(i, 4, new QTableWidgetItem(QString::number(imageInfoList[i].colorDepth)));
        tableWidget->setItem(i, 5, new QTableWidgetItem(imageInfoList[i].compression));
        tableWidget->setItem(i, 6, new QTableWidgetItem(QString::number(imageInfoList[i].compressionRatio, 'f', 2)));
    }
}
