#ifndef IMAGEINFOWINDOW_H
#define IMAGEINFOWINDOW_H

#include <QMainWindow>
#include <QTableWidget>
#include <QVector>
#include <QPushButton>
#include <QLineEdit>
#include "imageinfo.h"

class ImageInfoWindow : public QMainWindow {
    Q_OBJECT

public:
    ImageInfoWindow(QWidget *parent = nullptr);

private slots:
    void uploadFiles();
    void selectDownloadDirectory();
    void displayImageInfo(const QVector<ImageInfo>& imageInfoList);

private:
    QTableWidget *tableWidget;
    QPushButton *uploadButton;
    QPushButton *downloadDirButton;
    QLineEdit *downloadDirLineEdit;
};

#endif // IMAGEINFOWINDOW_H
