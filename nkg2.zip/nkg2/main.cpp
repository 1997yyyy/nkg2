#include <QApplication>
#include <QMainWindow>
#include "imageinfowindow.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    ImageInfoWindow window;
    window.setWindowTitle("Image Info Viewer");
    window.resize(800, 600);
    window.show();
    return app.exec();
}
