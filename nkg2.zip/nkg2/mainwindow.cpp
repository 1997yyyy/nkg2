#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHeaderView>
#include <QMimeDatabase>
#include <QImageReader>
#include <QImage>
#include <QStringList>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);

    QPushButton *selectFolderButton = new QPushButton("选择文件夹", this);
    connect(selectFolderButton, &QPushButton::clicked, this, &MainWindow::selectFolder);

    tableWidget = new QTableWidget(this);
    tableWidget->setColumnCount(5);
    tableWidget->setHorizontalHeaderLabels({"文件名", "图像大小", "分辨率", "颜色深度", "压缩"});
    tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    layout->addWidget(selectFolderButton);
    layout->addWidget(tableWidget);

    setCentralWidget(centralWidget);
    setWindowTitle("图像信息查看器");
}

void MainWindow::selectFolder() {
    QString folderPath = QFileDialog::getExistingDirectory(this, "选择文件夹");
    if (!folderPath.isEmpty()) {
        populateTable(folderPath);
    }
}

void MainWindow::populateTable(const QString &folderPath) {
    tableWidget->setRowCount(0);
    QDirIterator it(folderPath, QDir::Files, QDirIterator::Subdirectories);
    QMimeDatabase mimeDatabase;

    while (it.hasNext()) {
        QString filePath = it.next();
        QMimeType mimeType = mimeDatabase.mimeTypeForFile(filePath);
        qDebug() << "Checking file:" << filePath << "MIME type:" << mimeType.name(); // Debugging line

        if (mimeType.name().startsWith("image/")) {
            QImageReader reader(filePath);
            if (reader.canRead()) {
                QImage image = reader.read();
                if (!image.isNull()) {
                    tableWidget->insertRow(tableWidget->rowCount());

                    QTableWidgetItem *fileNameItem = new QTableWidgetItem(it.fileName());
                    QSize size = image.size();
                    QTableWidgetItem *sizeItem = new QTableWidgetItem(QString("%1 x %2").arg(size.width()).arg(size.height()));

                    int dpiX = image.dotsPerMeterX() * 0.0254; // 将点/米转换为点/英寸
                    int dpiY = image.dotsPerMeterY() * 0.0254; // 将点/米转换为点/英寸
                    QString resolution = (dpiX > 0 && dpiY > 0) ? QString("%1 x %2").arg(dpiX).arg(dpiY) : "N/A";
                    QTableWidgetItem *resolutionItem = new QTableWidgetItem(resolution);

                    QTableWidgetItem *colorDepthItem = new QTableWidgetItem(QString::number(image.depth()));
                    QTableWidgetItem *compressionItem = new QTableWidgetItem(getImageCompression(reader));

                    tableWidget->setItem(tableWidget->rowCount() - 1, 0, fileNameItem);
                    tableWidget->setItem(tableWidget->rowCount() - 1, 1, sizeItem);
                    tableWidget->setItem(tableWidget->rowCount() - 1, 2, resolutionItem);
                    tableWidget->setItem(tableWidget->rowCount() - 1, 3, colorDepthItem);
                    tableWidget->setItem(tableWidget->rowCount() - 1, 4, compressionItem);
                } else {
                    qDebug() << "Cannot read image:" << filePath; // Debugging line
                }
            } else {
                qDebug() << "Cannot read file as image:" << filePath; // Debugging line
            }
        } else {
            qDebug() << "Not an image file:" << filePath; // Debugging line
        }
    }
}

QString MainWindow::getImageCompression(const QImageReader &reader) {
    QString format = reader.format().toLower();
    if (format == "jpeg" || format == "jpg") {
        return "有损压缩";
    } else if (format == "png" || format == "gif") {
        return "无损压缩";
    } else {
        return "N/A";
    }
}
