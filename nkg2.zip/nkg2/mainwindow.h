#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTableWidget>
#include <QFileDialog>
#include <QDirIterator>
#include <QImageReader>
#include <QMimeDatabase>
#include <QPushButton>
#include <QStringList>

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

private slots:
    void selectFolder();

private:
    QTableWidget *tableWidget;
    void populateTable(const QString &folderPath);
    QString getImageCompression(const QImageReader &reader);
    QStringList getSupportedImageFormats();
};

#endif // MAINWINDOW_H
